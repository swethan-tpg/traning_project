package com.example.calculateSalary;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.calculateSalary.config.HikeConfig;
import com.example.calculateSalary.service.CalculateSalaryService;
@SpringBootTest
class CalculateSalaryApplicationTests {
 
    private HikeConfig hikeConfig;
    private CalculateSalaryService calculateSalaryService;
 
    @BeforeEach
    void setup() {
        hikeConfig = new HikeConfig();
        hikeConfig.setZeroToThree(5);
        hikeConfig.setFourToSix(10);
        hikeConfig.setSevenToTen(15);
        hikeConfig.setAboveTen(20);
 
        calculateSalaryService = new CalculateSalaryService();
    }
 
    @Test
    void testCalculateSalary() {
        assertEquals(52500.0, calculateSalaryService.calculateSalary(50000, 3));
        assertEquals(55000.0, calculateSalaryService.calculateSalary(50000, 5));
        assertEquals(57500.0, calculateSalaryService.calculateSalary(50000, 8));
        assertEquals(60000.0, calculateSalaryService.calculateSalary(50000, 12));
    }
}
