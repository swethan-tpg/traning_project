package com.example.calculateSalary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculateSalaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculateSalaryApplication.class, args);
	}

}
