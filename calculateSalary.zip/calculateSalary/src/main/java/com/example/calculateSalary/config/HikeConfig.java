package com.example.calculateSalary.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
 
@Configuration
@ConfigurationProperties(prefix = "hike.percentage")
public class HikeConfig {
    private int zeroToThree;
    private int fourToSix;
    private int sevenToTen;
    private int aboveTen;
 
    // Getters and Setters
    public int getZeroToThree() {
        return zeroToThree;
    }
 
    public void setZeroToThree(int zeroToThree) {
        this.zeroToThree = zeroToThree;
    }
 
    public int getFourToSix() {
        return fourToSix;
    }
 
    public void setFourToSix(int fourToSix) {
        this.fourToSix = fourToSix;
    }
 
    public int getSevenToTen() {
        return sevenToTen;
    }
 
    public void setSevenToTen(int sevenToTen) {
        this.sevenToTen = sevenToTen;
    }
 
    public int getAboveTen() {
        return aboveTen;
    }
 
    public void setAboveTen(int aboveTen) {
        this.aboveTen = aboveTen;
    }
}
