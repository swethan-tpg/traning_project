package com.example.calculateSalary.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import com.example.calculateSalary.service.CalculateSalaryService;

@RestController
@RequestMapping("/employees")
@CrossOrigin(origins="http://localhost:4200")
public class CalculateSalaryController {

	
	@Autowired
	private CalculateSalaryService Service;

	@GetMapping("/calculate-salary/{id}")
	public ResponseEntity<Double> calculateSalary(@PathVariable Long id) {

		double Result = Service.calculateHike(id);

		if (Result == 0) {
			return ResponseEntity.notFound().build();
		}

		return ResponseEntity.ok(Result);
	}
}
