package com.example.calculateSalary.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


import com.example.calculateSalary.model.Employee;
import com.example.calculateSalary.repository.EmployeeRepository;

@Service
public class CalculateSalaryService {
	@Autowired
	private EmployeeRepository repository;
	
	@Value("${hike10}")
	
	  private int hike10;
	@Value("${hike12}")
	  private int hike12;
	@Value("${hike7}")
	  private int hike7;
	@Value("${hike8}")
	  private int hike8;
	@Value("${hike9}")
	  private int hike9;
	
	public double calculateHike(Long id) {
		Employee employee = repository.findById(id).orElse(null);
		if (employee == null) {
			return 0;
		}

		// Calculate salary
		double basicSalary = employee.getBasicSalary();
		int yearsOfExperience = employee.getYearsOfExperience();

		return calculateSalary(basicSalary, yearsOfExperience);
	}
	
	public double calculateSalary(double basicSalary, int yearsOfExperience) {

		int hikePercentage;

		if (yearsOfExperience <5) {
			if(basicSalary<300000) {
			hikePercentage = hike12;
			}
			else
			{
				hikePercentage=hike10;
			}
			
			
		} else if (yearsOfExperience>=5&&yearsOfExperience < 7) {
			if(basicSalary<800000) {
				hikePercentage = hike10;
				}
				else
				{
					hikePercentage=hike8;
				}
		} else if (yearsOfExperience>=7&&yearsOfExperience < 10) {
			if(basicSalary<10000000) {
				hikePercentage = hike9;
				}
				else
				{
					hikePercentage=hike7;
				}
		} else {
			hikePercentage = hike7;
		}
		

		return basicSalary + (hikePercentage*basicSalary)/100;
	}

}
