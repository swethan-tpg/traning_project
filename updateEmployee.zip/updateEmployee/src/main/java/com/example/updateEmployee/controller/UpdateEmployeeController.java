package com.example.updateEmployee.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.updateEmployee.model.Employee;
import com.example.updateEmployee.repository.EmployeeRepository;
 
@RestController
@RequestMapping("/employees")
@CrossOrigin(origins="http://localhost:4200")
public class UpdateEmployeeController {
 
    @Autowired
    private EmployeeRepository repository;
 
    @PutMapping("/update/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
        if (repository.existsById(id)) {
            employee.setId(id); // Ensure the ID is set for update
            Employee updatedEmployee = repository.save(employee);
            return ResponseEntity.ok(updatedEmployee);
        }
        return ResponseEntity.notFound().build();
    }
}