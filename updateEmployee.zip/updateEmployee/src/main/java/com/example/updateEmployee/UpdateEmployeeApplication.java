package com.example.updateEmployee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpdateEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(UpdateEmployeeApplication.class, args);
	}

}
