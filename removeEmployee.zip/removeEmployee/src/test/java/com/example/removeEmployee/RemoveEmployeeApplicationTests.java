package com.example.removeEmployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RemoveEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}

///*import com.example.common.repository.EmployeeRepository;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
// 
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
// 
//class RemoveEmployeeServiceTest {
// 
//    @Mock
//    private EmployeeRepository employeeRepository;
// 
//    @InjectMocks
//    private RemoveEmployeeService removeEmployeeService;
// 
//    RemoveEmployeeServiceTest() {
//        MockitoAnnotations.openMocks(this);
//    }
// 
//    @Test
//    void testRemoveEmployee() {
//        Long employeeId = 1L;
//        when(employeeRepository.existsById(employeeId)).thenReturn(true);
// 
//        removeEmployeeService.removeEmployee(employeeId);
// 
//        verify(employeeRepository).deleteById(employeeId);
//    }
//}*/

