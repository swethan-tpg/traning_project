package com.example.removeEmployee.service;

import org.springframework.stereotype.Service;

@Service
public class RemoveEmployeService {

	
}
