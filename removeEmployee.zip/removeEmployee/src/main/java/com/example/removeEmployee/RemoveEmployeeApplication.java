package com.example.removeEmployee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RemoveEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RemoveEmployeeApplication.class, args);
	}

}
