package com.example.viewEmployee.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.viewEmployee.model.Employee;
import com.example.viewEmployee.repository.EmployeeRepository;

@RestController
@RequestMapping("/employees")
@CrossOrigin(origins="http://localhost:4200")
public class ViewEmployeeController {

	@Autowired
	private EmployeeRepository repository;

	@GetMapping("/view/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) {
		
		
		return repository.findById(id).map(employee -> ResponseEntity.ok(employee))
				.orElseGet(() -> ResponseEntity.notFound().build());
		
		
	}
}