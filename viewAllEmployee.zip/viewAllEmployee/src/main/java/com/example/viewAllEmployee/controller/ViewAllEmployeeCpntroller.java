package com.example.viewAllEmployee.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.viewAllEmployee.model.Employee;
import com.example.viewAllEmployee.repository.EmployeeRepository;

import java.util.List;
 
@RestController
@RequestMapping("/employees")
@CrossOrigin(origins="http://localhost:4200")
public class ViewAllEmployeeCpntroller {
 
    @Autowired
    private EmployeeRepository repository;
 
    @GetMapping("/view-all")
    public ResponseEntity<List<Employee>> getAllEmployees() {
        List<Employee> employees = repository.findAll();
        if (employees.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(employees);
    }
}