package com.example.viewAllEmployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViewAllEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}



/*
 * import com.example.common.model.Employee; import
 * com.example.common.repository.EmployeeRepository; import
 * org.junit.jupiter.api.Test; import org.mockito.InjectMocks; import
 * org.mockito.Mock; import org.mockito.MockitoAnnotations;
 * 
 * import java.util.Arrays; import java.util.List;
 * 
 * import static org.junit.jupiter.api.Assertions.assertEquals; import static
 * org.mockito.Mockito.when;
 * 
 * class ViewAllEmployeesServiceTest {
 * 
 * @Mock private EmployeeRepository employeeRepository;
 * 
 * @InjectMocks private ViewAllEmployeesService viewAllEmployeesService;
 * 
 * ViewAllEmployeesServiceTest() { MockitoAnnotations.openMocks(this); }
 * 
 * @Test void testViewAllEmployees() { List<Employee> employees = Arrays.asList(
 * new Employee(1L, "Alice", 28, "Female", "123 Elm Street", 5, 45000.0), new
 * Employee(2L, "Bob", 35, "Male", "456 Oak Avenue", 10, 60000.0) );
 * when(employeeRepository.findAll()).thenReturn(employees);
 * 
 * List<Employee> result = viewAllEmployeesService.viewAllEmployees();
 * 
 * assertEquals(2, result.size()); } }
 */