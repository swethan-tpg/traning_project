/*
 * package com.example.addEmploye;
 * 
 * import org.junit.jupiter.api.Test; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * 
 * 
 * import com.example.common.model.Employee; import
 * com.example.common.repository.EmployeeRepository; import
 * org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.MockitoAnnotations;
 * 
 * import static org.mockito.Mockito.verify; import static
 * org.mockito.Mockito.when;
 * 
 * class AddEmployeApplicationTests {
 * 
 * @Mock private EmployeeRepository employeeRepository;
 * 
 * @InjectMocks private AddEmployeeService addEmployeeService;
 * 
 * AddEmployeeServiceTest() { MockitoAnnotations.openMocks(this); }
 * 
 * @Test void testAddEmployee() { Employee employee = new Employee(1L, "Alice",
 * 28, "Female", "123 Elm Street", 5, 45000.0);
 * when(employeeRepository.save(employee)).thenReturn(employee);
 * 
 * Employee result = addEmployeeService.addEmployee(employee);
 * 
 * verify(employeeRepository).save(employee); } }
 */