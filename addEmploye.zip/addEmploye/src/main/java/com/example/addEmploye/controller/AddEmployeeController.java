package com.example.addEmploye.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.addEmploye.model.Employee;
import com.example.addEmploye.repository.EmployeeRepository;




@RestController
@RequestMapping("employees")
@CrossOrigin(origins="http://localhost:4200")
public class AddEmployeeController {
	
	@GetMapping("/health")
public String serverUP () {
		return "Add Employee Server is up";
	}
	
	@Autowired
	private EmployeeRepository repository;
	
	@PostMapping("/add")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee){
		Employee savedEmployee=repository.save(employee);
		return new
				ResponseEntity<>(savedEmployee,HttpStatus.CREATED);
	}
	
	@PostMapping("/add-all")
	public ResponseEntity<List<Employee>> addAllEmployee(@RequestBody List<Employee> employees){
		List<Employee> savedEmployee=repository.saveAll(employees);
		return new
				ResponseEntity<>(savedEmployee,HttpStatus.CREATED);
	}
	
}
