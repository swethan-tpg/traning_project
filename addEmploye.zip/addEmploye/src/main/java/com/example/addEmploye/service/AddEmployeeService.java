package com.example.addEmploye.service;

import org.springframework.stereotype.Service;

@Service
public class AddEmployeeService {

}
