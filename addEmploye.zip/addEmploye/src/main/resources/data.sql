INSERT INTO employee (Employee_Name, Employee_Age, Employee_Gender, Employee_Address, YearsOfExperience, BasicSalary)
VALUES
('Alice Smith', 28, 'Female', '456 Oak St', 4, 40000),
('Bob Johnson', 35, 'Male', '789 Pine St', 8, 70000);